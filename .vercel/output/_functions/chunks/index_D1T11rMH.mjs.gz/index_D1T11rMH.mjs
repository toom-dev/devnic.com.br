import { jsxs, jsx } from 'react/jsx-runtime';
import { C as Container, I as Image } from './Layout_SnyiQcvI.mjs';
import 'react';

const ImageContent = ({
  data: { aboveTitle, title, description, imagePosition, image }
}) => {
  if (!image && !title) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-20 lg:py-32 bg-gradient-to-br from-gray-50 via-white to-gray-100 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 opacity-10", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-10 w-40 h-40 bg-blue-200 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-10 w-48 h-48 bg-purple-200 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx("div", { className: "relative z-10", children: /* @__PURE__ */ jsxs(
      "div",
      {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center",
        "data-animate": true,
        children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: `relative ${imagePosition === "left" ? "lg:order-1" : "lg:order-2"}`,
              children: /* @__PURE__ */ jsxs("div", { className: "relative group", children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl transform rotate-3 group-hover:rotate-6 transition-transform duration-500" }),
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-purple-100/30 to-pink-100/30 rounded-3xl transform -rotate-3 group-hover:-rotate-6 transition-transform duration-500" }),
                /* @__PURE__ */ jsx("div", { className: "relative bg-white rounded-3xl p-4 shadow-2xl border border-gray-200 group-hover:shadow-3xl transition-all duration-500", children: /* @__PURE__ */ jsx("div", { className: "rounded-2xl overflow-hidden", children: image && /* @__PURE__ */ jsx(
                  Image,
                  {
                    srcLocal: image,
                    alt: `${title} - Devnic Web Solutions`,
                    className: "relative w-full h-full object-cover object-center rounded-2xl shadow-xl border-4 border-gray-100"
                  }
                ) }) }),
                /* @__PURE__ */ jsx("div", { className: "absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300", children: /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 10V3L4 14h7v7l9-11h-7z" }) }) }),
                /* @__PURE__ */ jsx("div", { className: "absolute -bottom-4 -left-4 w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300", children: /* @__PURE__ */ jsx("svg", { className: "w-10 h-10 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" }) }) })
              ] })
            }
          ),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: `space-y-8 ${imagePosition === "left" ? "lg:order-2" : "lg:order-1"}`,
              children: [
                aboveTitle && /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200", children: /* @__PURE__ */ jsx("span", { className: "text-blue-700 font-medium text-sm uppercase tracking-wide", children: aboveTitle }) }),
                title && /* @__PURE__ */ jsx("h2", { className: "text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 leading-tight mb-8", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent", children: title }) }),
                description && /* @__PURE__ */ jsx("p", { className: "text-lg lg:text-xl text-gray-600 leading-relaxed max-w-2xl", children: description }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Soluções personalizadas para seu negócio" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Implementação rápida e eficiente" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Suporte contínuo e treinamento" })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "pt-4", children: /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: "#contato",
                    className: "inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 font-semibold group",
                    children: [
                      /* @__PURE__ */ jsx("span", { children: "Começar Agora" }),
                      /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 group-hover:translate-x-1 transition-transform duration-300", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 8l4 4m0 0l-4 4m4-4H3" }) })
                    ]
                  }
                ) })
              ]
            }
          )
        ]
      }
    ) }) })
  ] });
};

const Testimonials = ({
  data: { authors, description, aboveTitle, title }
}) => {
  if (!authors.length) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-20 lg:py-32 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-20 w-64 h-64 bg-blue-200/50 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-20 w-80 h-80 bg-purple-200/50 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-200/30 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-20", "data-animate": true, children: [
        aboveTitle && /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-50 to-purple-50 backdrop-blur-sm border border-blue-200 mb-6", children: /* @__PURE__ */ jsx("span", { className: "text-blue-600 font-medium text-sm uppercase tracking-wide", children: aboveTitle }) }),
        title && /* @__PURE__ */ jsx("h2", { className: "text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent", children: title }) }),
        description && /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed", children: description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-8 lg:grid-cols-3 items-start", children: authors.map((author, index) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "group relative bg-white/80 backdrop-blur-md rounded-3xl p-8 lg:p-10 border border-gray-200 hover:border-gray-300 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl",
          "data-animate": true,
          style: { animationDelay: `${index * 200}ms` },
          children: [
            /* @__PURE__ */ jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsx("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsx("svg", { className: "w-6 h-6 text-white", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h4v10h-10z" }) }) }) }),
            /* @__PURE__ */ jsxs("blockquote", { className: "text-lg lg:text-xl text-gray-600 leading-relaxed mb-8 grow", children: [
              '"',
              author.testimonial || "Excelente serviço!",
              '"'
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 pt-6 border-t border-gray-200", children: [
              /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg", children: author.name ? author.name.charAt(0).toUpperCase() : "A" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("div", { className: "text-gray-900 font-semibold text-lg", children: author.name || "Cliente Satisfeito" }),
                /* @__PURE__ */ jsx("div", { className: "text-blue-600 text-sm font-medium", children: author.role || "Empresa" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 mt-4", children: [
              [...Array(5)].map((_, i) => /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 text-yellow-400", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }, i)),
              /* @__PURE__ */ jsx("span", { className: "text-gray-500 text-sm ml-2", children: "5.0" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/5 group-hover:to-pink-500/5 rounded-3xl transition-all duration-500" })
          ]
        },
        index
      )) }),
      /* @__PURE__ */ jsxs("div", { className: "text-center mt-16", "data-animate": true, children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-8 mb-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-gray-700", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-green-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "100% dos clientes recomendam" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-gray-700", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Avaliação média: 5.0 estrelas" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-gray-700", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Resultados em até 90 dias" })
          ] })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-gray-500 text-sm max-w-2xl mx-auto", children: "Estes são apenas alguns dos nossos clientes satisfeitos. Sua empresa pode ser a próxima a alcançar resultados extraordinários." })
      ] })
    ] }) })
  ] });
};

export { ImageContent as I, Testimonials as T };
