/* empty css                                           */
import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_ClLhG9vG.mjs';
import 'kleur/colors';
import { C as Container, $ as $$Layout } from '../chunks/Layout_BCyZ_LWY.mjs';
import { S as Service } from '../chunks/index_BY5H58c8.mjs';
import { I as ImageContent, T as Testimonials } from '../chunks/index_DrLbCNQf.mjs';
import { jsxs, jsx } from 'react/jsx-runtime';
import { useState, useRef, useEffect } from 'react';
export { renderers } from '../renderers.mjs';

const useCountUp = (end, duration = 2e3) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) {
      observer.observe(ref.current);
    }
    return () => observer.disconnect();
  }, [isVisible]);
  useEffect(() => {
    if (!isVisible) return;
    let startTime;
    let animationId;
    const animate = (currentTime) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const easeOutCubic = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(easeOutCubic * end));
      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      }
    };
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isVisible, end, duration]);
  return { count, ref };
};
const Stats = ({ data: { title, stats } }) => {
  if (!stats || stats.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-16 sm:py-24 lg:py-32 bg-gradient-to-br from-white via-gray-50 to-blue-50 relative overflow-hidden", children: [
    /* @__PURE__ */ jsx("div", { className: "absolute inset-0 opacity-5", children: /* @__PURE__ */ jsx("div", { className: "absolute inset-0", style: {
      backgroundImage: "radial-gradient(circle at 25px 25px, rgb(99 102 241) 2px, transparent 0), radial-gradient(circle at 75px 75px, rgb(139 92 246) 2px, transparent 0)",
      backgroundSize: "100px 100px"
    } }) }),
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 overflow-hidden pointer-events-none", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-20 w-32 h-32 bg-blue-400/20 rounded-full blur-3xl animate-pulse-slow" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-20 w-40 h-40 bg-purple-400/20 rounded-full blur-3xl animate-pulse-slow", style: { animationDelay: "1s" } }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-indigo-400/15 rounded-full blur-3xl animate-pulse-slow", style: { animationDelay: "2s" } })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-16 lg:mb-20", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-3 px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-full mb-6 animate-fade-in-up", children: [
          /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 text-blue-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" }) }),
          /* @__PURE__ */ jsx("span", { className: "text-blue-700 font-semibold text-sm", children: "Resultados Comprovados" })
        ] }),
        /* @__PURE__ */ jsxs("h2", { className: "text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight animate-fade-in-up animation-delay-200", children: [
          /* @__PURE__ */ jsx("span", { className: "block", children: "Números que" }),
          /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent", children: "Falam por Si" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full animate-fade-in-up animation-delay-400" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8", children: stats.map((stat, index) => {
        const numericValue = parseInt(stat.number.replace(/\D/g, "")) || 0;
        const { count, ref } = useCountUp(numericValue, 2e3 + index * 200);
        const suffix = stat.number.replace(/\d/g, "");
        return /* @__PURE__ */ jsxs(
          "div",
          {
            ref,
            className: "group relative bg-white/80 backdrop-blur-sm rounded-3xl p-6 lg:p-8 border border-gray-200 hover:border-blue-300 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl animate-fade-in-up",
            style: { animationDelay: `${600 + index * 150}ms` },
            children: [
              /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-50/0 to-purple-50/0 group-hover:from-blue-50/50 group-hover:to-purple-50/50 rounded-3xl transition-all duration-500" }),
              /* @__PURE__ */ jsx("div", { className: "relative z-10 mb-4", children: /* @__PURE__ */ jsxs("div", { className: "w-16 h-16 mx-auto bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110", children: [
                index === 0 && /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" }) }),
                index === 1 && /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" }) }),
                index === 2 && /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" }) }),
                index === 3 && /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" }) })
              ] }) }),
              /* @__PURE__ */ jsxs("div", { className: "relative z-10 text-center", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2", children: [
                  count,
                  suffix
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-lg font-semibold text-gray-700 mb-1", children: stat.label }),
                /* @__PURE__ */ jsx("div", { className: "w-12 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "absolute top-4 right-4 w-6 h-6 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" })
            ]
          },
          index
        );
      }) }),
      /* @__PURE__ */ jsx("div", { className: "text-center mt-16 lg:mt-20 animate-fade-in-up animation-delay-1000", children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl mx-auto", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-lg text-gray-600 mb-8", children: [
          "Estes números refletem o compromisso da Devnic em entregar resultados excepcionais.",
          /* @__PURE__ */ jsx("span", { className: "font-semibold text-gray-800", children: " Sua empresa pode ser a próxima a alcançar esses resultados." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-4", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => document.getElementById("contato")?.scrollIntoView({ behavior: "smooth" }),
              className: "group bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transform transition-all duration-300 hover:scale-105",
              children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
                "Quero Estes Resultados",
                /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 group-hover:translate-x-1 transition-transform", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 8l4 4m0 0l-4 4m4-4H3" }) })
              ] })
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "https://wa.me/5511989266354?text=Olá! Vi os resultados da Devnic e gostaria de saber como posso alcançar os mesmos números na minha empresa.",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-gray-600 hover:text-gray-800 font-medium flex items-center gap-2 transition-colors",
              children: [
                /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 text-green-600", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.488" }) }),
                "Falar pelo WhatsApp"
              ]
            }
          )
        ] })
      ] }) })
    ] }) })
  ] });
};

const $$InfraestruturaCloud = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Infraestrutura & Cloud Computing | Consultoria Devnic - S\xE3o Paulo", "description": "Migre para a nuvem com seguran\xE7a total! A Devnic gerencia sua infraestrutura, otimiza servidores e garante 99.9% de disponibilidade. Migra\xE7\xE3o cloud sem riscos. Diagn\xF3stico gratuito em SP!" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <section id="hero" class="bg-white py-20 px-4"> <div class="max-w-6xl mx-auto text-center"> <div class="inline-flex items-center gap-2 px-4 py-2 bg-cyan-50 rounded-full text-cyan-600 text-sm font-medium mb-8"> <span class="w-2 h-2 bg-cyan-500 rounded-full"></span>
Infraestrutura & Cloud Computing
</div> <h1 class="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
Infraestrutura cloud<br> <span class="text-cyan-600">de alto desempenho</span> </h1> <p class="text-xl text-gray-600 max-w-3xl mx-auto mb-10 leading-relaxed">
Migração segura para a nuvem, 99.9% de uptime garantido e redução de 50% nos custos. 
                    Sua empresa sempre online, sempre protegida.
</p> <div class="flex flex-col sm:flex-row gap-4 justify-center mb-16"> <button onclick="window.openContactForm && window.openContactForm('Infraestrutura & Cloud')" class="bg-cyan-600 hover:bg-cyan-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors">
Migrar para Cloud
</button> <a href="#metodologia" class="border border-gray-300 hover:border-gray-400 text-gray-700 px-8 py-4 rounded-lg font-semibold transition-colors">
Ver Nossa Metodologia
</a> </div> </div> </section> ${renderComponent($$result2, "Stats", Stats, { "data": {
    title: "Performance que Sua Empresa Precisa",
    stats: [
      {
        number: "99.9%",
        label: "Garantia de uptime"
      },
      {
        number: "50%",
        label: "Redu\xE7\xE3o m\xE9dia de custos"
      },
      {
        number: "80+",
        label: "Migra\xE7\xF5es bem-sucedidas"
      },
      {
        number: "24/7",
        label: "Monitoramento cont\xEDnuo"
      }
    ]
  } })} <section id="problemas"> <div class="bg-red-50 py-16"> <div class="container mx-auto px-4"> <div class="text-center mb-12"> <h2 class="text-3xl md:text-4xl font-bold text-red-600 mb-6">
⚠️ Sua Empresa Está Perdendo Dinheiro a Cada Segundo
</h2> <p class="text-xl text-gray-700 max-w-3xl mx-auto">
Servidores instáveis, custos descontrolados e falta de escalabilidade 
                            estão matando a produtividade da sua empresa!
</p> </div> <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"> <div class="bg-white p-6 rounded-lg shadow-lg"> <h3 class="text-xl font-bold text-red-600 mb-4">💸 Custos Descontrolados</h3> <p>Servidores físicos custam 3x mais que soluções cloud otimizadas</p> </div> <div class="bg-white p-6 rounded-lg shadow-lg"> <h3 class="text-xl font-bold text-red-600 mb-4">🔥 Indisponibilidades Frequentes</h3> <p>Cada hora de downtime custa em média R$ 5.000 para empresas médias</p> </div> <div class="bg-white p-6 rounded-lg shadow-lg"> <h3 class="text-xl font-bold text-red-600 mb-4">📈 Falta de Escalabilidade</h3> <p>Impossível crescer rapidamente com infraestrutura engessada</p> </div> <div class="bg-white p-6 rounded-lg shadow-lg"> <h3 class="text-xl font-bold text-red-600 mb-4">🛡️ Vulnerabilidades de Segurança</h3> <p>Servidores mal configurados são portas abertas para ataques</p> </div> </div> </div> </div> </section> ${renderComponent($$result2, "Service", Service, { "data": {
    aboveTitle: "Nossa Metodologia Cloud",
    title: "Migra\xE7\xE3o Segura e Otimiza\xE7\xE3o Completa da Sua Infraestrutura",
    description: "Processo estruturado em 4 etapas para garantir uma migra\xE7\xE3o sem riscos e m\xE1ximo desempenho.",
    services: [
      {
        title: "Auditoria Completa de Infraestrutura",
        description: "An\xE1lise detalhada dos seus sistemas atuais, identifica\xE7\xE3o de gargalos e mapeamento de requisitos para a nuvem.",
        icon: "fingerprint"
      },
      {
        title: "Planejamento de Migra\xE7\xE3o",
        description: "Estrat\xE9gia personalizada com cronograma, custos detalhados e plano de conting\xEAncia para zero downtime.",
        icon: "gradient"
      },
      {
        title: "Implementa\xE7\xE3o Monitorada",
        description: "Migra\xE7\xE3o gradual com testes constantes, backup completo e acompanhamento 24/7 durante todo o processo.",
        icon: "cloud"
      },
      {
        title: "Otimiza\xE7\xE3o Cont\xEDnua",
        description: "Monitoramento ativo, ajustes de performance e otimiza\xE7\xE3o de custos para m\xE1xima efici\xEAncia operacional.",
        icon: "repeat"
      }
    ]
  } })} <section id="beneficios"> ${renderComponent($$result2, "ImageContent", ImageContent, { "data": {
    aboveTitle: "Transforme Sua Infraestrutura",
    title: "Da Dor de Cabe\xE7a \xE0 Tranquilidade Total em 30 Dias",
    description: "Nossa infraestrutura cloud n\xE3o \xE9 apenas mais barata - \xE9 mais segura, mais r\xE1pida e permite que sua empresa cres\xE7a sem limita\xE7\xF5es. Com monitoramento 24/7 e suporte especializado, voc\xEA ter\xE1 a tranquilidade de saber que sua tecnologia est\xE1 sempre funcionando perfeitamente.",
    image: "about",
    imagePosition: "right"
  } })} </section> <section id="caso-sucesso"> ${renderComponent($$result2, "ImageContent", ImageContent, { "data": {
    aboveTitle: "Caso de Sucesso Comprovado",
    title: "E-commerce Evitou Preju\xEDzo de R$ 200 Mil com Nossa Infraestrutura Cloud",
    description: "Um e-commerce estava perdendo vendas por instabilidade durante picos de tr\xE1fego. Migramos toda infraestrutura para cloud com auto-scaling. Resultado: Zero downtime durante a Black Friday, aumento de 300% na capacidade de processamento e redu\xE7\xE3o de 45% nos custos mensais de infraestrutura.",
    image: "partner",
    imagePosition: "left"
  } })} </section> ${renderComponent($$result2, "Testimonials", Testimonials, { "data": {
    aboveTitle: "Clientes Que Dormir Tranquilo",
    title: "Veja Como Eliminamos os Problemas de TI dos Nossos Clientes",
    description: "Empresas que confiaram em nossa expertise agora t\xEAm infraestrutura \xE0 prova de falhas.",
    authors: [
      {
        name: "Roberto Silva",
        role: "CTO - TechStart",
        testimonial: "Antes da Devnic, t\xEDnhamos problemas semanais com servidores. Hoje, h\xE1 8 meses sem nenhuma indisponibilidade. A migra\xE7\xE3o cloud foi perfeita e economizamos 40% por m\xEAs.",
        avatar: "about"
      },
      {
        name: "Fernanda Costa",
        role: "Diretora de TI - ComercioDigital",
        testimonial: "Nossa Black Friday foi um sucesso total! O sistema aguentou 10x mais tr\xE1fego que o normal sem piscar. A Devnic salvou nosso faturamento anual.",
        avatar: "partner"
      }
    ]
  } })} <section id="urgencia"> <div class="bg-gradient-to-r from-red-600 to-orange-600 text-white py-16"> <div class="container mx-auto px-4 text-center"> <h2 class="text-3xl md:text-4xl font-bold mb-6">
🚨 ATENÇÃO: Sua Infraestrutura Atual é uma Bomba-Relógio!
</h2> <p class="text-xl mb-8 max-w-3xl mx-auto">
A cada dia que você adia a migração para cloud, aumenta o risco de:
<br>💥 Perda total de dados | 💸 Prejuízos por downtime | 🎯 Ataques cibernéticos
</p> <div class="bg-yellow-400 text-black p-6 rounded-lg max-w-2xl mx-auto mb-8"> <p class="text-lg font-bold">
⚡ MIGRAÇÃO EXPRESSA: Complete sua migração cloud em apenas 15 dias
<br>🎁 BONUS: 3 meses de monitoramento GRATUITO!
</p> </div> <p class="text-lg mb-8">
Últimas 5 vagas para migração expressa este mês!
</p> </div> </div> </section> <section id="contato" class="py-20 bg-gray-50"> <div class="max-w-4xl mx-auto px-4 text-center"> <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
Transforme sua infraestrutura com <span class="text-cyan-600">nossa migração cloud</span> </h2> <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
Não arrisque mais seu negócio! Migração segura para cloud com uptime garantido. 
                    Diagnóstico gratuito e sem compromisso.
</p> <div class="flex flex-col sm:flex-row gap-4 justify-center mb-8"> <button onclick="window.openContactForm && window.openContactForm('Infraestrutura & Cloud')" class="bg-cyan-600 hover:bg-cyan-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors inline-flex items-center justify-center">
Migrar para Cloud Agora
<svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path> </svg> </button> <a href="tel:+5511989266354" class="border border-gray-300 hover:border-gray-400 text-gray-700 px-8 py-4 rounded-lg font-semibold transition-colors inline-flex items-center justify-center"> <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"> <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path> </svg>
Ligar Agora
</a> </div> <div class="text-sm text-gray-500"> <span class="inline-flex items-center gap-2"> <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path> </svg>
Sem compromisso
</span> <span class="mx-4">•</span> <span class="inline-flex items-center gap-2"> <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path> </svg>
99.9% uptime garantido
</span> <span class="mx-4">•</span> <span class="inline-flex items-center gap-2"> <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path> </svg>
Migração sem downtime
</span> </div> </div> </section> </main> ` })}`;
}, "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/infraestrutura-cloud.astro", void 0);

const $$file = "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/infraestrutura-cloud.astro";
const $$url = "/infraestrutura-cloud";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$InfraestruturaCloud,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
