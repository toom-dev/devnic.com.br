/* empty css                                      */
import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_ClLhG9vG.mjs';
import 'kleur/colors';
import { $ as $$Layout, I as Image } from '../chunks/Layout_D2tr2yfG.mjs';
/* empty css                                      */
export { renderers } from '../renderers.mjs';

const $$Automacoes = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Automa\xE7\xE3o de Processos Empresariais | Devnic - S\xE3o Paulo", "description": "Automatize processos e elimine tarefas manuais! A Devnic cria solu\xE7\xF5es de automa\xE7\xE3o que reduzem custos em 60% e aumentam produtividade. Rob\xF4s digitais, integra\xE7\xE3o de sistemas e workflows inteligentes. Diagn\xF3stico gratuito!", "data-astro-cid-s7rcy3b4": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content" data-astro-cid-s7rcy3b4> <!-- Hero Section - Nova Bootstrap Style --> <section class="hero-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="row align-items-center min-vh-80" data-astro-cid-s7rcy3b4> <div class="col-12 col-lg-6 order-2 order-lg-1" data-astro-cid-s7rcy3b4> <div class="hero-content" data-astro-cid-s7rcy3b4> <div class="hero-badge" data-astro-cid-s7rcy3b4> <span class="badge-custom" data-astro-cid-s7rcy3b4>
🚀 Resultados Garantidos em 60 dias
</span> </div> <h1 class="hero-title" data-astro-cid-s7rcy3b4>
A melhor forma de <span class="text-gradient" data-astro-cid-s7rcy3b4>automatizar seus processos</span> e converter resultados
</h1> <p class="hero-description" data-astro-cid-s7rcy3b4>
Solução de automação de alta conversão feita para empresas que querem crescer. 
                                Construída com tecnologia avançada e metodologia comprovada. Comece agora!
</p> <div class="hero-buttons" data-astro-cid-s7rcy3b4> <button onclick="window.location.href='#contato'" class="btn btn-primary-custom btn-lg" data-astro-cid-s7rcy3b4>
Experimente Automação GRÁTIS
</button> <div class="hero-note" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>✓ Diagnóstico Gratuito</span> <span data-astro-cid-s7rcy3b4>✓ Sem Compromisso</span> </div> </div> </div> </div> <div class="col-12 col-lg-6 order-1 order-lg-2" data-astro-cid-s7rcy3b4> <div class="hero-image" data-astro-cid-s7rcy3b4> <div class="hero-image-wrapper" data-astro-cid-s7rcy3b4> <div class="hero-img-container" data-astro-cid-s7rcy3b4> <div class="hero-img-bg" data-astro-cid-s7rcy3b4></div> </div> <div class="floating-element floating-element-1" data-astro-cid-s7rcy3b4> <div class="stat-card" data-astro-cid-s7rcy3b4> <div class="stat-number" data-astro-cid-s7rcy3b4>60%</div> <div class="stat-label" data-astro-cid-s7rcy3b4>Redução de Custos</div> </div> </div> <div class="floating-element floating-element-2" data-astro-cid-s7rcy3b4> <div class="stat-card" data-astro-cid-s7rcy3b4> <div class="stat-number" data-astro-cid-s7rcy3b4>24/7</div> <div class="stat-label" data-astro-cid-s7rcy3b4>Operação</div> </div> </div> </div> </div> </div> </div> </div> </section> <!-- Trusted By Section --> <section class="trusted-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="text-center" data-astro-cid-s7rcy3b4> <h6 class="trusted-title" data-astro-cid-s7rcy3b4>Confiado por centenas de empresas</h6> <div class="logos-wrapper" data-astro-cid-s7rcy3b4> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 1</div> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 2</div> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 3</div> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 4</div> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 5</div> <div class="client-logo-placeholder" data-astro-cid-s7rcy3b4>Cliente 6</div> </div> </div> </div> </section> <!-- Features Section --> <section class="features-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="row align-items-center" data-astro-cid-s7rcy3b4> <div class="col-12 col-lg-6" data-astro-cid-s7rcy3b4> <div class="features-content" data-astro-cid-s7rcy3b4> <h2 class="section-title" data-astro-cid-s7rcy3b4>
Automatize seus processos de forma eficaz com a Devnic
</h2> <div class="feature-items" data-astro-cid-s7rcy3b4> <div class="feature-item" data-astro-cid-s7rcy3b4> <div class="feature-icon" data-astro-cid-s7rcy3b4> <div class="icon-wrapper icon-blue" data-astro-cid-s7rcy3b4> <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24" data-astro-cid-s7rcy3b4> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-s7rcy3b4></path> </svg> </div> </div> <div class="feature-content" data-astro-cid-s7rcy3b4> <h5 class="feature-title" data-astro-cid-s7rcy3b4>Focado na Experiência</h5> <p class="feature-description" data-astro-cid-s7rcy3b4>
Nossa metodologia garante máxima eficiência e zero erros operacionais. 
                                            Processos otimizados que se adaptam ao seu negócio.
</p> </div> </div> <div class="feature-item" data-astro-cid-s7rcy3b4> <div class="feature-icon" data-astro-cid-s7rcy3b4> <div class="icon-wrapper icon-green" data-astro-cid-s7rcy3b4> <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24" data-astro-cid-s7rcy3b4> <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" data-astro-cid-s7rcy3b4></path> </svg> </div> </div> <div class="feature-content" data-astro-cid-s7rcy3b4> <h5 class="feature-title" data-astro-cid-s7rcy3b4>Converte Resultados</h5> <p class="feature-description" data-astro-cid-s7rcy3b4>
Processos otimizados que geram ROI imediato e crescimento sustentável. 
                                            Aumento de produtividade comprovado.
</p> </div> </div> <div class="feature-item" data-astro-cid-s7rcy3b4> <div class="feature-icon" data-astro-cid-s7rcy3b4> <div class="icon-wrapper icon-purple" data-astro-cid-s7rcy3b4> <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24" data-astro-cid-s7rcy3b4> <path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" data-astro-cid-s7rcy3b4></path> <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" data-astro-cid-s7rcy3b4></path> </svg> </div> </div> <div class="feature-content" data-astro-cid-s7rcy3b4> <h5 class="feature-title" data-astro-cid-s7rcy3b4>Customizações Fáceis</h5> <p class="feature-description" data-astro-cid-s7rcy3b4>
Soluções flexíveis que se adaptam perfeitamente ao seu negócio. 
                                            Configuração simples e intuitiva.
</p> </div> </div> </div> <div class="features-cta" data-astro-cid-s7rcy3b4> <a href="#servicos" class="btn btn-outline-custom" data-astro-cid-s7rcy3b4>
Saiba Mais →
</a> </div> </div> </div> <div class="col-12 col-lg-6" data-astro-cid-s7rcy3b4> <div class="features-image" data-astro-cid-s7rcy3b4> ${renderComponent($$result2, "Image", Image, { "srcLocal": "automacao", "alt": "Automa\xE7\xE3o em A\xE7\xE3o", "className": "features-img", "data-astro-cid-s7rcy3b4": true })} </div> </div> </div> </div> </section> <!-- Highlights Section --> <section id="servicos" class="highlights-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="text-center mb-5" data-astro-cid-s7rcy3b4> <h2 class="section-title" data-astro-cid-s7rcy3b4>Destaques das Funcionalidades</h2> <p class="section-subtitle" data-astro-cid-s7rcy3b4>
Descubra como nossas soluções podem transformar sua empresa
</p> </div> <div class="row g-4" data-astro-cid-s7rcy3b4> <div class="col-12 col-md-6" data-astro-cid-s7rcy3b4> <div class="highlight-card" data-astro-cid-s7rcy3b4> <div class="highlight-image" data-astro-cid-s7rcy3b4> <div class="highlight-img-placeholder" data-astro-cid-s7rcy3b4>🤖 Robôs Digitais</div> </div> <div class="highlight-content" data-astro-cid-s7rcy3b4> <h5 class="highlight-title" data-astro-cid-s7rcy3b4>Robôs Digitais Inteligentes</h5> <p class="highlight-description" data-astro-cid-s7rcy3b4>
Robôs que trabalham 24/7 sem erros operacionais. Automatização completa 
                                    de tarefas repetitivas com precisão máxima.
</p> <a href="#contato" class="highlight-link" data-astro-cid-s7rcy3b4>
Saiba mais →
</a> </div> </div> </div> <div class="col-12 col-md-6" data-astro-cid-s7rcy3b4> <div class="highlight-card" data-astro-cid-s7rcy3b4> <div class="highlight-image" data-astro-cid-s7rcy3b4> <div class="highlight-img-placeholder" data-astro-cid-s7rcy3b4>🔗 Integração</div> </div> <div class="highlight-content" data-astro-cid-s7rcy3b4> <h5 class="highlight-title" data-astro-cid-s7rcy3b4>Integração de Sistemas</h5> <p class="highlight-description" data-astro-cid-s7rcy3b4>
Conectamos todos os seus sistemas em uma única plataforma. 
                                    Fluxo de dados unificado e sincronizado.
</p> <a href="#contato" class="highlight-link" data-astro-cid-s7rcy3b4>
Saiba mais →
</a> </div> </div> </div> <div class="col-12 col-md-6" data-astro-cid-s7rcy3b4> <div class="highlight-card" data-astro-cid-s7rcy3b4> <div class="highlight-image" data-astro-cid-s7rcy3b4> <div class="highlight-img-placeholder" data-astro-cid-s7rcy3b4>⚡ Workflows</div> </div> <div class="highlight-content" data-astro-cid-s7rcy3b4> <h5 class="highlight-title" data-astro-cid-s7rcy3b4>Workflows Inteligentes</h5> <p class="highlight-description" data-astro-cid-s7rcy3b4>
Processos otimizados que aumentam produtividade em 300%. 
                                    Automação inteligente adaptada ao seu negócio.
</p> <a href="#contato" class="highlight-link" data-astro-cid-s7rcy3b4>
Saiba mais →
</a> </div> </div> </div> <div class="col-12 col-md-6" data-astro-cid-s7rcy3b4> <div class="highlight-card" data-astro-cid-s7rcy3b4> <div class="highlight-image" data-astro-cid-s7rcy3b4> <div class="highlight-img-placeholder" data-astro-cid-s7rcy3b4>📊 Monitoramento</div> </div> <div class="highlight-content" data-astro-cid-s7rcy3b4> <h5 class="highlight-title" data-astro-cid-s7rcy3b4>Monitoramento Contínuo</h5> <p class="highlight-description" data-astro-cid-s7rcy3b4>
Acompanhamento em tempo real de todos os processos automatizados. 
                                    Relatórios detalhados e alertas inteligentes.
</p> <a href="#contato" class="highlight-link" data-astro-cid-s7rcy3b4>
Saiba mais →
</a> </div> </div> </div> </div> <div class="text-center mt-5" data-astro-cid-s7rcy3b4> <a href="#contato" class="btn btn-primary-custom btn-lg" data-astro-cid-s7rcy3b4>
Ver Todas as Funcionalidades
</a> </div> </div> </section> <!-- CTA Section --> <section class="cta-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="cta-content" data-astro-cid-s7rcy3b4> <h2 class="cta-title" data-astro-cid-s7rcy3b4>
Pronto para transformar seus visitantes em resultados reais?
</h2> <p class="cta-description" data-astro-cid-s7rcy3b4>
Experimente a Automação Devnic Hoje GRÁTIS. Elimine tarefas manuais e multiplique 
                        seus resultados. Nossa metodologia já otimizou centenas de processos empresariais.
</p> <div class="cta-buttons" data-astro-cid-s7rcy3b4> <button onclick="window.location.href='#contato'" class="btn btn-primary-custom btn-lg" data-astro-cid-s7rcy3b4>
Baixar Diagnóstico - É GRÁTIS
</button> <div class="cta-guarantee" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>✓ 100% Gratuito</span> <span data-astro-cid-s7rcy3b4>✓ Sem Compromisso</span> <span data-astro-cid-s7rcy3b4>✓ Resultados em 60 dias</span> </div> </div> </div> </div> </section> <!-- Testimonials Section --> <section class="testimonials-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="text-center mb-5" data-astro-cid-s7rcy3b4> <h2 class="section-title" data-astro-cid-s7rcy3b4>
Amado por milhares de empresários como você
</h2> <p class="section-subtitle" data-astro-cid-s7rcy3b4>
Veja o que nossos clientes têm a dizer sobre nossas soluções
</p> </div> <div class="row g-4" data-astro-cid-s7rcy3b4> <div class="col-12 col-md-6 col-lg-4" data-astro-cid-s7rcy3b4> <div class="testimonial-card" data-astro-cid-s7rcy3b4> <div class="testimonial-content" data-astro-cid-s7rcy3b4> <div class="testimonial-rating" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>⭐⭐⭐⭐⭐</span> </div> <h6 class="testimonial-title" data-astro-cid-s7rcy3b4>Aplicativo Incrível!</h6> <p class="testimonial-text" data-astro-cid-s7rcy3b4>
"A automação da Devnic transformou nossa empresa. Eliminamos 80% das tarefas manuais 
                                    e aumentamos nossa produtividade em 300%. ROI alcançado em apenas 2 meses!"
</p> <div class="testimonial-author" data-astro-cid-s7rcy3b4> <div class="author-info" data-astro-cid-s7rcy3b4> <strong class="author-name" data-astro-cid-s7rcy3b4>Carlos Silva</strong> <span class="author-role" data-astro-cid-s7rcy3b4>CEO - TechSolutions</span> </div> </div> </div> </div> </div> <div class="col-12 col-md-6 col-lg-4" data-astro-cid-s7rcy3b4> <div class="testimonial-card" data-astro-cid-s7rcy3b4> <div class="testimonial-content" data-astro-cid-s7rcy3b4> <div class="testimonial-rating" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>⭐⭐⭐⭐⭐</span> </div> <h6 class="testimonial-title" data-astro-cid-s7rcy3b4>Maravilhoso!</h6> <p class="testimonial-text" data-astro-cid-s7rcy3b4>
"Nossa equipe agora foca no que realmente importa. Os robôs digitais cuidam de tudo 
                                    automaticamente. Economia de R$ 200 mil por ano em custos operacionais."
</p> <div class="testimonial-author" data-astro-cid-s7rcy3b4> <div class="author-info" data-astro-cid-s7rcy3b4> <strong class="author-name" data-astro-cid-s7rcy3b4>Ana Paula</strong> <span class="author-role" data-astro-cid-s7rcy3b4>Diretora - LogisCorp</span> </div> </div> </div> </div> </div> <div class="col-12 col-md-6 col-lg-4" data-astro-cid-s7rcy3b4> <div class="testimonial-card" data-astro-cid-s7rcy3b4> <div class="testimonial-content" data-astro-cid-s7rcy3b4> <div class="testimonial-rating" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>⭐⭐⭐⭐⭐</span> </div> <h6 class="testimonial-title" data-astro-cid-s7rcy3b4>Impressionante!</h6> <p class="testimonial-text" data-astro-cid-s7rcy3b4>
"Implementação rápida e resultados imediatos. Em 60 dias já víamos 40% de redução 
                                    nos custos. A melhor decisão que tomamos para nossa empresa."
</p> <div class="testimonial-author" data-astro-cid-s7rcy3b4> <div class="author-info" data-astro-cid-s7rcy3b4> <strong class="author-name" data-astro-cid-s7rcy3b4>Roberto Lima</strong> <span class="author-role" data-astro-cid-s7rcy3b4>Fundador - InnovaCorp</span> </div> </div> </div> </div> </div> </div> <div class="text-center mt-5" data-astro-cid-s7rcy3b4> <button onclick="window.location.href='#contato'" class="btn btn-primary-custom" data-astro-cid-s7rcy3b4>
Experimente Agora
</button> </div> </div> </section> <!-- Contact Section --> <section id="contato" class="contact-section" data-astro-cid-s7rcy3b4> <div class="container" data-astro-cid-s7rcy3b4> <div class="contact-content" data-astro-cid-s7rcy3b4> <div class="contact-header" data-astro-cid-s7rcy3b4> <h2 class="contact-title" data-astro-cid-s7rcy3b4>
Obtenha a automação
</h2> <p class="contact-description" data-astro-cid-s7rcy3b4>
Baixe nossa automação agora. Elimine tarefas manuais e multiplique seus resultados. 
                            Nossa metodologia já transformou centenas de empresas em todo o Brasil.
</p> </div> <div class="contact-buttons" data-astro-cid-s7rcy3b4> <button onclick="window.location.href='tel:+5511989266354'" class="btn btn-primary-custom btn-lg" data-astro-cid-s7rcy3b4>
📞 Ligar Agora
</button> <button onclick="window.openContactForm && window.openContactForm('Automação de Processos')" class="btn btn-outline-custom btn-lg" data-astro-cid-s7rcy3b4>
📧 Falar por Email
</button> </div> <div class="contact-guarantee" data-astro-cid-s7rcy3b4> <span data-astro-cid-s7rcy3b4>✓ Resposta em até 2 horas</span> <span data-astro-cid-s7rcy3b4>✓ Consultoria gratuita</span> <span data-astro-cid-s7rcy3b4>✓ Sem compromisso</span> </div> </div> </div> </section> </main>  ` })}`;
}, "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/automacoes.astro", void 0);

const $$file = "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/automacoes.astro";
const $$url = "/automacoes";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Automacoes,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
