/* empty css                                           */
import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_C0nYQaw9.mjs';
import 'kleur/colors';
import { jsx, jsxs } from 'react/jsx-runtime';
import * as React from 'react';
import { useState } from 'react';
import { B as Button } from '../chunks/index_BFmwnfU_.mjs';
import { C as Container, I as Image, $ as $$Layout } from '../chunks/Layout_DumuuwtG.mjs';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import InputMask from 'react-input-mask';
export { renderers } from '../renderers.mjs';

const SvgIconThemeDark = (props) => /* @__PURE__ */ React.createElement("svg", { fill: "#000000", width: "50px", height: "50px", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", ...props }, /* @__PURE__ */ React.createElement("g", { id: "Dark" }, /* @__PURE__ */ React.createElement("path", { d: "M12.741,20.917a9.389,9.389,0,0,1-1.395-.105,9.141,9.141,0,0,1-1.465-17.7,1.177,1.177,0,0,1,1.21.281,1.273,1.273,0,0,1,.325,1.293,8.112,8.112,0,0,0-.353,2.68,8.266,8.266,0,0,0,4.366,6.857,7.628,7.628,0,0,0,3.711.993,1.242,1.242,0,0,1,.994,1.963h0A9.148,9.148,0,0,1,12.741,20.917ZM10.261,4.05a.211.211,0,0,0-.065.011,8.137,8.137,0,1,0,9.131,12.526h0a.224.224,0,0,0,.013-.235.232.232,0,0,0-.206-.136A8.619,8.619,0,0,1,14.946,15.1a9.274,9.274,0,0,1-4.883-7.7,9.123,9.123,0,0,1,.4-3.008.286.286,0,0,0-.069-.285A.184.184,0,0,0,10.261,4.05Z" })));

const SvgIconThemeLight = (props) => /* @__PURE__ */ React.createElement("svg", { fill: "#000000", width: "50px", height: "50px", viewBox: "-7.5 0 32 32", xmlns: "http://www.w3.org/2000/svg", ...props }, /* @__PURE__ */ React.createElement("title", null, "dark"), /* @__PURE__ */ React.createElement("path", { d: "M9.75 8.25v0.219c0 0.844-0.375 1.25-1.156 1.25s-1.125-0.406-1.125-1.25v-0.219c0-0.813 0.344-1.219 1.125-1.219s1.156 0.406 1.156 1.219zM12.063 9.25l0.156-0.188c0.469-0.688 1.031-0.781 1.625-0.344 0.625 0.438 0.719 1.031 0.25 1.719l-0.188 0.156c-0.469 0.688-1.031 0.781-1.625 0.313-0.625-0.438-0.688-0.969-0.219-1.656zM5 9.063l0.125 0.188c0.469 0.688 0.406 1.219-0.188 1.656-0.625 0.469-1.219 0.375-1.688-0.313l-0.125-0.156c-0.469-0.688-0.406-1.281 0.188-1.719 0.625-0.438 1.219-0.281 1.688 0.344zM8.594 11.125c2.656 0 4.844 2.188 4.844 4.875 0 2.656-2.188 4.813-4.844 4.813-2.688 0-4.844-2.156-4.844-4.813 0-2.688 2.156-4.875 4.844-4.875zM1.594 12.5l0.219 0.063c0.813 0.25 1.063 0.719 0.844 1.469-0.25 0.75-0.75 0.969-1.531 0.719l-0.219-0.063c-0.781-0.25-1.063-0.719-0.844-1.469 0.25-0.75 0.75-0.969 1.531-0.719zM15.375 12.563l0.219-0.063c0.813-0.25 1.313-0.031 1.531 0.719s-0.031 1.219-0.844 1.469l-0.188 0.063c-0.813 0.25-1.313 0.031-1.531-0.719-0.25-0.75 0.031-1.219 0.813-1.469zM8.594 18.688c1.469 0 2.688-1.219 2.688-2.688 0-1.5-1.219-2.719-2.688-2.719-1.5 0-2.719 1.219-2.719 2.719 0 1.469 1.219 2.688 2.719 2.688zM0.906 17.281l0.219-0.063c0.781-0.25 1.281-0.063 1.531 0.688 0.219 0.75-0.031 1.219-0.844 1.469l-0.219 0.063c-0.781 0.25-1.281 0.063-1.531-0.688-0.219-0.75 0.063-1.219 0.844-1.469zM16.094 17.219l0.188 0.063c0.813 0.25 1.063 0.719 0.844 1.469s-0.719 0.938-1.531 0.688l-0.219-0.063c-0.781-0.25-1.063-0.719-0.813-1.469 0.219-0.75 0.719-0.938 1.531-0.688zM3.125 21.563l0.125-0.188c0.469-0.688 1.063-0.75 1.688-0.313 0.594 0.438 0.656 0.969 0.188 1.656l-0.125 0.188c-0.469 0.688-1.063 0.75-1.688 0.313-0.594-0.438-0.656-0.969-0.188-1.656zM13.906 21.375l0.188 0.188c0.469 0.688 0.375 1.219-0.25 1.656-0.594 0.438-1.156 0.375-1.625-0.313l-0.156-0.188c-0.469-0.688-0.406-1.219 0.219-1.656 0.594-0.438 1.156-0.375 1.625 0.313zM9.75 23.469v0.25c0 0.844-0.375 1.25-1.156 1.25s-1.125-0.406-1.125-1.25v-0.25c0-0.844 0.344-1.25 1.125-1.25s1.156 0.406 1.156 1.25z" }));

const SvgIconCloud = (props) => /* @__PURE__ */ React.createElement("svg", { className: "h-6 w-6 text-white", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", "aria-hidden": "true", ...props }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" }));

const SvgIconFingerprint = (props) => /* @__PURE__ */ React.createElement("svg", { className: "h-6 w-6 text-white", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", "aria-hidden": "true", ...props }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M7.864 4.243A7.5 7.5 0 0119.5 10.5c0 2.92-.556 5.709-1.568 8.268M5.742 6.364A7.465 7.465 0 004.5 10.5a7.464 7.464 0 01-1.15 3.993m1.989 3.559A11.209 11.209 0 008.25 10.5a3.75 3.75 0 117.5 0c0 .527-.021 1.049-.064 1.565M12 10.5a14.94 14.94 0 01-3.6 9.75m6.633-4.596a18.666 18.666 0 01-2.485 5.33" }));

const SvgIconRepeat = (props) => /* @__PURE__ */ React.createElement("svg", { className: "h-6 w-6 text-white", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", "aria-hidden": "true", ...props }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" }));

const SvgIconLock = (props) => /* @__PURE__ */ React.createElement("svg", { className: "h-6 w-6 text-white", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", ...props }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" }));

const SvgIconGradient = (props) => /* @__PURE__ */ React.createElement("svg", { viewBox: "0 0 1024 1024", "aria-hidden": "true", ...props }, /* @__PURE__ */ React.createElement("circle", { cx: 512, cy: 512, r: 512, fill: "url(#759c1415-0410-454c-8f7c-9a820de03641)", fillOpacity: 0.7 }), /* @__PURE__ */ React.createElement("defs", null, /* @__PURE__ */ React.createElement("radialGradient", { id: "759c1415-0410-454c-8f7c-9a820de03641", cx: 0, cy: 0, r: 1, gradientUnits: "userSpaceOnUse", gradientTransform: "translate(512 512) rotate(90) scale(512)" }, /* @__PURE__ */ React.createElement("stop", { stopColor: "#7775D6" }), /* @__PURE__ */ React.createElement("stop", { offset: 1, stopColor: "#E935C1", stopOpacity: 0 }))));

const SvgIconTestimonial = (props) => /* @__PURE__ */ React.createElement("svg", { viewBox: "0 0 24 20", xmlns: "http://www.w3.org/2000/svg", fill: "#fff", ...props }, /* @__PURE__ */ React.createElement("path", { d: "M0 13.517c0-2.346.611-4.774 1.833-7.283C3.056 3.726 4.733 1.648 6.865 0L11 2.696C9.726 4.393 8.777 6.109 8.152 7.844c-.624 1.735-.936 3.589-.936 5.56v4.644H0v-4.531zm13 0c0-2.346.611-4.774 1.833-7.283 1.223-2.508 2.9-4.586 5.032-6.234L24 2.696c-1.274 1.697-2.223 3.413-2.848 5.148-.624 1.735-.936 3.589-.936 5.56v4.644H13v-4.531z" }));

const icons = {
  themeDark: SvgIconThemeDark,
  themeLight: SvgIconThemeLight,
  cloud: SvgIconCloud,
  fingerprint: SvgIconFingerprint,
  repeat: SvgIconRepeat,
  lock: SvgIconLock,
  testimonial: SvgIconTestimonial,
  gradient: SvgIconGradient
};
const Icon = ({ name, ...rest }) => {
  const IconComponent = icons[name];
  return /* @__PURE__ */ jsx(IconComponent, { ...rest });
};

const CenterText = ({
  title,
  description,
  buttons,
  image
}) => {
  if (!title && !description) {
    return null;
  }
  return /* @__PURE__ */ jsx("div", { className: "mt-32 md:mt-40 md:mb-16", children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: "text-center flex justify-center flex-col items-center gap-5",
      "data-animate": true,
      children: [
        /* @__PURE__ */ jsx("h1", { className: "text-h2-md md:text-h1-md lg:text-h1-lg font-bold opacity-90", children: title }),
        description && /* @__PURE__ */ jsx("p", { className: "text-p-md sm:text-p-leading max-w-lg opacity-50 margin-p last:margin-p-last", children: description }),
        buttons && /* @__PURE__ */ jsx("div", { className: "max-w-xs mx-auto gap-5 sm:max-w-none flex justify-center flex-col sm:flex-row ", children: buttons.map((button, index) => /* @__PURE__ */ jsx(
          Button,
          {
            variant: button.variant,
            link: button.link,
            children: button.text
          },
          index
        )) }),
        image && /* @__PURE__ */ jsx("figure", { className: "max-w-xl mt-10", children: /* @__PURE__ */ jsx(Image, { srcLocal: image, alt: "hero image" }) })
      ]
    }
  ) }) });
};

const ContentImage = ({
  title,
  description,
  button,
  image,
  label,
  logo
}) => {
  if (!title && !description) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "relative bg-gradient-to-br from-blue-50 via-white to-gray-50 w-full min-h-screen overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-0 -left-4 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-0 -right-4 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob animation-delay-2000" }),
      /* @__PURE__ */ jsx("div", { className: "absolute -bottom-8 left-20 w-72 h-72 bg-indigo-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob animation-delay-4000" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative w-full grid lg:grid-cols-2 grid-cols-1 min-h-screen", children: [
      /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center py-16 px-6 lg:py-20 lg:px-12 xl:px-20", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl lg:mx-0 space-y-8", "data-animate": true, children: [
        logo && /* @__PURE__ */ jsx("div", { className: "animate-fadeInUp", children: /* @__PURE__ */ jsx(
          Image,
          {
            srcLocal: logo,
            alt: "logo",
            className: "max-w-48 lg:max-w-60 filter drop-shadow-lg"
          }
        ) }),
        label && /* @__PURE__ */ jsx("div", { className: "animate-fadeInUp animation-delay-200", children: /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center rounded-full bg-gradient-to-r from-blue-100 to-indigo-100 backdrop-blur-sm border border-blue-200 px-6 py-3 text-sm leading-6 text-blue-800 shadow-lg", children: [
          /* @__PURE__ */ jsx("span", { className: "text-blue-600 mr-2", children: "✨" }),
          label,
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "https://wa.me/5511989266354?text=Olá! Gostaria de saber mais sobre os serviços da Devnic.",
              target: "_blank",
              className: "whitespace-nowrap font-semibold text-blue-700 ml-3 hover:text-blue-800 transition-colors duration-200",
              children: [
                "Falar com Especialista",
                /* @__PURE__ */ jsx("span", { "aria-hidden": "true", className: "ml-1", children: "→" })
              ]
            }
          )
        ] }) }),
        title && /* @__PURE__ */ jsx("div", { className: "animate-fadeInUp animation-delay-400", children: /* @__PURE__ */ jsx("h1", { className: "text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 leading-tight mb-8", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent", children: title }) }) }),
        description && /* @__PURE__ */ jsx("p", { className: "animate-fadeInUp animation-delay-600 text-lg lg:text-xl leading-relaxed text-gray-700 max-w-2xl", children: description }),
        button && button.link && /* @__PURE__ */ jsxs("div", { className: "animate-fadeInUp animation-delay-800 flex flex-col sm:flex-row items-start sm:items-center gap-4", children: [
          /* @__PURE__ */ jsx(
            Button,
            {
              variant: button.variant,
              link: button.link,
              className: "bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white font-bold px-8 py-4 rounded-xl shadow-xl hover:shadow-2xl transform transition-all duration-300 hover:scale-105 hover:-translate-y-1",
              children: button.text
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-sm text-gray-600", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex -space-x-2", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-gradient-to-r from-blue-400 to-blue-600 border-2 border-white shadow-sm" }),
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-gradient-to-r from-indigo-400 to-indigo-600 border-2 border-white shadow-sm" }),
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-gradient-to-r from-purple-400 to-purple-600 border-2 border-white shadow-sm" })
            ] }),
            /* @__PURE__ */ jsx("span", { children: "+50 empresas confiam em nós" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "animate-fadeInUp animation-delay-1000 flex flex-wrap items-center gap-6 pt-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-green-600", children: [
            /* @__PURE__ */ jsx("svg", { className: "w-5 h-5", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z", clipRule: "evenodd" }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm text-gray-700 font-medium", children: "Garantia de 90 dias" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-blue-600", children: [
            /* @__PURE__ */ jsx("svg", { className: "w-5 h-5", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z", clipRule: "evenodd" }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm text-gray-700 font-medium", children: "100% Seguro" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-yellow-600", children: [
            /* @__PURE__ */ jsx("svg", { className: "w-5 h-5", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm text-gray-700 font-medium", children: "Avaliação 5.0 estrelas" })
          ] })
        ] })
      ] }) }),
      image && /* @__PURE__ */ jsxs("div", { className: "relative w-full h-64 lg:h-full min-h-96 lg:min-h-screen", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-l from-transparent via-blue-50/20 to-white/60" }),
        /* @__PURE__ */ jsx(
          Image,
          {
            srcLocal: image,
            alt: label,
            className: "relative inset-0 w-full h-full object-cover object-center"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "absolute top-10 right-10 hidden lg:block", children: /* @__PURE__ */ jsx("div", { className: "bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-blue-100 shadow-xl", children: /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
          /* @__PURE__ */ jsx("div", { className: "text-3xl font-bold text-blue-600", children: "300%" }),
          /* @__PURE__ */ jsx("div", { className: "text-sm text-gray-600", children: "Aumento médio" })
        ] }) }) }),
        /* @__PURE__ */ jsx("div", { className: "absolute bottom-10 right-10 hidden lg:block", children: /* @__PURE__ */ jsx("div", { className: "bg-white/90 backdrop-blur-md rounded-2xl p-4 border border-green-100 shadow-xl", children: /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
          /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold text-green-600", children: "90 dias" }),
          /* @__PURE__ */ jsx("div", { className: "text-sm text-gray-600", children: "Para resultados" })
        ] }) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce", children: /* @__PURE__ */ jsx("div", { className: "w-6 h-10 border-2 border-gray-400 rounded-full flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "w-1 h-3 bg-gray-500 rounded-full mt-2 animate-pulse" }) }) })
  ] });
};

const Hero = ({ heroType, data, ...rest }) => {
  if (!data) {
    return null;
  }
  let HeroTypeOutput;
  switch (heroType) {
    case "center":
      HeroTypeOutput = /* @__PURE__ */ jsx(CenterText, { ...data, ...rest });
    case "contentImage":
      HeroTypeOutput = /* @__PURE__ */ jsx(ContentImage, { ...data, ...rest });
      break;
  }
  const isFullWidth = heroType === "contentImage" ? "w-full" : "";
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: ` ${isFullWidth + " "} flex items-center justify-center`,
      children: HeroTypeOutput
    }
  );
};

const Logos = ({ data: { logos, title } }) => {
  if (!logos.length) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-16 lg:py-24 bg-gradient-to-br from-gray-100 via-white to-blue-50 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 opacity-10", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-10 left-1/4 w-32 h-32 bg-blue-300 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-10 right-1/4 w-40 h-40 bg-purple-300 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "relative z-10 text-center", children: [
      title && /* @__PURE__ */ jsxs("div", { className: "mb-16", "data-animate": true, children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl lg:text-4xl font-bold text-gray-900 mb-4", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent", children: title }) }),
        /* @__PURE__ */ jsx("div", { className: "w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mb-12", "data-animate": true, children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-6 text-gray-600", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("div", { className: "w-6 h-6 bg-green-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-3 h-3 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
          /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: "Clientes desde 2020" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("div", { className: "w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-3 h-3 text-white", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }) }),
          /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: "100% Satisfação" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("div", { className: "w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-3 h-3 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }) }) }),
          /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: "Suporte 24/7" })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-8 max-w-4xl mx-auto", "data-animate": true, children: logos.map((logo, index) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl border border-gray-100 transition-all duration-500 hover:-translate-y-1",
          style: { animationDelay: `${index * 200}ms` },
          children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-50/0 to-purple-50/0 group-hover:from-blue-50/50 group-hover:to-purple-50/50 rounded-2xl transition-all duration-500" }),
            /* @__PURE__ */ jsx("div", { className: "relative z-10 flex items-center justify-center h-24", children: /* @__PURE__ */ jsx(
              Image,
              {
                srcLocal: logo,
                alt: "company logo",
                className: "max-h-16 w-auto object-contain filter grayscale group-hover:grayscale-0 transition-all duration-500 transform group-hover:scale-110"
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "absolute top-3 right-3 w-4 h-4 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" })
          ]
        },
        index
      )) }),
      /* @__PURE__ */ jsx("div", { className: "mt-16 max-w-3xl mx-auto", "data-animate": true, children: /* @__PURE__ */ jsxs("div", { className: "bg-white/70 backdrop-blur-sm rounded-3xl p-8 border border-white/50 shadow-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center mb-4", children: [...Array(5)].map((_, i) => /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 text-yellow-400", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }, i)) }),
        /* @__PURE__ */ jsx("blockquote", { className: "text-lg text-gray-700 italic mb-4", children: '"A Devnic transformou completamente nossos processos. Em menos de 6 meses, conseguimos automatizar 80% das nossas tarefas manuais e aumentar a produtividade da equipe significativamente."' }),
        /* @__PURE__ */ jsx("div", { className: "text-gray-600 font-medium", children: "— CEO de uma das empresas parceiras" })
      ] }) })
    ] }) })
  ] });
};

const Service = ({
  data: { aboveTitle, title, description, services }
}) => {
  if (!services.length) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-20 lg:py-32 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 opacity-30", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-10 w-32 h-32 bg-blue-300 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-10 w-40 h-40 bg-purple-300 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-pink-300 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-20", "data-animate": true, children: [
        aboveTitle && /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 mb-6", children: /* @__PURE__ */ jsx("span", { className: "text-blue-600 font-medium text-sm uppercase tracking-wide", children: aboveTitle }) }),
        title && /* @__PURE__ */ jsx("h2", { className: "text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 leading-tight mb-8", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent", children: title }) }),
        description && /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed", children: description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12", children: services.map((service, index) => /* @__PURE__ */ jsxs("article", { className: "group relative bg-white/80 backdrop-blur-sm rounded-3xl p-8 lg:p-10 border border-white/50 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 hover:scale-105", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-50/0 via-purple-50/0 to-pink-50/0 group-hover:from-blue-50/50 group-hover:via-purple-50/30 group-hover:to-pink-50/50 rounded-3xl transition-all duration-500" }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
          /* @__PURE__ */ jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsx("div", { className: "w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110", children: /* @__PURE__ */ jsx(
            Icon,
            {
              name: service.icon,
              className: "h-8 w-8 text-white"
            }
          ) }) }),
          /* @__PURE__ */ jsx("h3", { className: "text-2xl lg:text-3xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300", children: service.title }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-700 text-lg leading-relaxed", children: service.description }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center mt-6 text-blue-600 font-medium group-hover:text-purple-600 transition-colors duration-300", children: [
            /* @__PURE__ */ jsx("span", { className: "mr-2", children: "Saiba mais" }),
            /* @__PURE__ */ jsx(
              "svg",
              {
                className: "w-5 h-5 transform group-hover:translate-x-1 transition-transform duration-300",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 8l4 4m0 0l-4 4m4-4H3" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "absolute top-4 right-4 w-20 h-20 bg-gradient-to-br from-blue-200/20 to-purple-200/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" })
      ] }, service.title)) }),
      /* @__PURE__ */ jsx("div", { className: "text-center mt-16", "data-animate": true, children: /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-4 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group", children: [
        /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Vamos conversar sobre seu projeto" }),
        /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 group-hover:translate-x-1 transition-transform duration-300", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 8l4 4m0 0l-4 4m4-4H3" }) })
      ] }) })
    ] }) })
  ] });
};

const ImageContent = ({
  data: { aboveTitle, title, description, imagePosition, image }
}) => {
  if (!image && !title) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-20 lg:py-32 bg-gradient-to-br from-white via-gray-50 to-blue-50 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 opacity-20", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-10 w-40 h-40 bg-blue-300 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-10 w-48 h-48 bg-purple-300 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx("div", { className: "relative z-10", children: /* @__PURE__ */ jsxs(
      "div",
      {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center",
        "data-animate": true,
        children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: `relative ${imagePosition === "left" ? "lg:order-1" : "lg:order-2"}`,
              children: /* @__PURE__ */ jsxs("div", { className: "relative group", children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-3xl transform rotate-3 group-hover:rotate-6 transition-transform duration-500" }),
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-3xl transform -rotate-3 group-hover:-rotate-6 transition-transform duration-500" }),
                /* @__PURE__ */ jsx("div", { className: "relative bg-white rounded-3xl p-4 shadow-2xl border border-gray-100 group-hover:shadow-3xl transition-all duration-500", children: /* @__PURE__ */ jsx("div", { className: "rounded-2xl overflow-hidden", children: image && /* @__PURE__ */ jsx(
                  Image,
                  {
                    srcLocal: image,
                    alt: `${title} - Devnic Web Solutions`,
                    className: "relative w-full h-full object-cover object-center rounded-2xl shadow-xl border-4 border-white/20"
                  }
                ) }) }),
                /* @__PURE__ */ jsx("div", { className: "absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300", children: /* @__PURE__ */ jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 10V3L4 14h7v7l9-11h-7z" }) }) }),
                /* @__PURE__ */ jsx("div", { className: "absolute -bottom-4 -left-4 w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300", children: /* @__PURE__ */ jsx("svg", { className: "w-10 h-10 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" }) }) })
              ] })
            }
          ),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: `space-y-8 ${imagePosition === "left" ? "lg:order-2" : "lg:order-1"}`,
              children: [
                aboveTitle && /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200", children: /* @__PURE__ */ jsx("span", { className: "text-blue-600 font-medium text-sm uppercase tracking-wide", children: aboveTitle }) }),
                title && /* @__PURE__ */ jsx("h2", { className: "text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 leading-tight mb-8", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent", children: title }) }),
                description && /* @__PURE__ */ jsx("p", { className: "text-lg lg:text-xl text-gray-600 leading-relaxed max-w-2xl", children: description }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Soluções personalizadas para seu negócio" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Implementação rápida e eficiente" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
                    /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Suporte contínuo e treinamento" })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "pt-4", children: /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: "#contato",
                    className: "inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 font-semibold group",
                    children: [
                      /* @__PURE__ */ jsx("span", { children: "Começar Agora" }),
                      /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 group-hover:translate-x-1 transition-transform duration-300", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 8l4 4m0 0l-4 4m4-4H3" }) })
                    ]
                  }
                ) })
              ]
            }
          )
        ]
      }
    ) }) })
  ] });
};

const Testimonials = ({
  data: { authors, description, aboveTitle, title }
}) => {
  if (!authors.length) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-20 lg:py-32 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-20 w-64 h-64 bg-blue-500/20 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-20 w-80 h-80 bg-purple-500/20 rounded-full filter blur-3xl" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500/10 rounded-full filter blur-3xl" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-20", "data-animate": true, children: [
        aboveTitle && /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-white/20 mb-6", children: /* @__PURE__ */ jsx("span", { className: "text-blue-300 font-medium text-sm uppercase tracking-wide", children: aboveTitle }) }),
        title && /* @__PURE__ */ jsx("h2", { className: "text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-white via-blue-100 to-purple-200 bg-clip-text text-transparent", children: title }) }),
        description && /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed", children: description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-8 lg:grid-cols-3 items-start", children: authors.map((author, index) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "group relative bg-white/10 backdrop-blur-md rounded-3xl p-8 lg:p-10 border border-white/20 hover:border-white/30 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl",
          "data-animate": true,
          style: { animationDelay: `${index * 200}ms` },
          children: [
            /* @__PURE__ */ jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsx("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsx("svg", { className: "w-6 h-6 text-white", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h4v10h-10z" }) }) }) }),
            /* @__PURE__ */ jsxs("blockquote", { className: "text-lg lg:text-xl text-gray-200 leading-relaxed mb-8 grow", children: [
              '"',
              author.content,
              '"'
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 pt-6 border-t border-white/10", children: [
              /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold text-lg", children: author.authorName.charAt(0) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("div", { className: "text-white font-semibold text-lg", children: author.authorName }),
                /* @__PURE__ */ jsx("div", { className: "text-blue-300 text-sm font-medium", children: author.authorRole })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 mt-4", children: [
              [...Array(5)].map((_, i) => /* @__PURE__ */ jsx("svg", { className: "w-5 h-5 text-yellow-400", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }, i)),
              /* @__PURE__ */ jsx("span", { className: "text-gray-400 text-sm ml-2", children: "5.0" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/5 group-hover:to-pink-500/5 rounded-3xl transition-all duration-500" })
          ]
        },
        index
      )) }),
      /* @__PURE__ */ jsxs("div", { className: "text-center mt-16", "data-animate": true, children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-8 mb-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-white", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-green-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "100% dos clientes recomendam" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-white", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Avaliação média: 5.0 estrelas" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-white", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Resultados em até 90 dias" })
          ] })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-gray-400 text-sm max-w-2xl mx-auto", children: "Estes são apenas alguns dos nossos clientes satisfeitos. Sua empresa pode ser a próxima a alcançar resultados extraordinários." })
      ] })
    ] }) })
  ] });
};

const contactSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres").max(100, "Nome muito longo").regex(/^[a-zA-ZÀ-ÿ\s]+$/, "Nome deve conter apenas letras e espaços"),
  email: z.string().min(1, "Email é obrigatório").email("Email inválido").toLowerCase(),
  phone: z.string().min(1, "Telefone é obrigatório").regex(/^\(\d{2}\)\s\d{4,5}-\d{4}$/, "Formato de telefone inválido").transform((phone) => phone.replace(/\D/g, "")),
  // Remove formatação para salvar
  message: z.string().max(1e3, "Mensagem muito longa").optional()
});
const Newsletter = ({
  data: { button, title }
}) => {
  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch
  } = useForm({
    resolver: zodResolver(contactSchema),
    mode: "onBlur"
    // Valida quando o campo perde o foco
  });
  const onSubmit = async (data) => {
    setIsLoading(true);
    setMessage(null);
    try {
      const formData = new FormData();
      formData.append("name", data.name);
      formData.append("email", data.email);
      formData.append("phone", data.phone);
      formData.append("message", data.message || "");
      const response = await fetch("/api/send-email", {
        method: "POST",
        body: formData
      });
      const result = await response.json();
      if (result.success) {
        setMessage({
          type: "success",
          text: "🎉 Mensagem enviada! Nossa equipe entrará em contato em breve."
        });
        reset();
        setTimeout(() => {
          window.location.href = "/contato-enviado";
        }, 2e3);
      } else {
        setMessage({
          type: "error",
          text: result.error || "Erro ao enviar mensagem. Tente novamente."
        });
      }
    } catch (error) {
      console.error("Erro:", error);
      setMessage({
        type: "error",
        text: "Erro de conexão. Verifique sua internet e tente novamente."
      });
    } finally {
      setIsLoading(false);
    }
  };
  if (!title) {
    return null;
  }
  return /* @__PURE__ */ jsxs("section", { className: "py-24 lg:py-32 bg-gradient-to-br from-purple-900 via-blue-900 to-slate-900 relative overflow-hidden", "data-animate": true, id: "contato", children: [
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-20 left-20 w-64 h-64 bg-blue-500/20 rounded-full filter blur-3xl animate-blob" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-20 right-20 w-80 h-80 bg-purple-500/20 rounded-full filter blur-3xl animate-blob animation-delay-2000" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500/10 rounded-full filter blur-3xl animate-blob animation-delay-4000" })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx("div", { className: "relative z-10 max-w-6xl mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "grid lg:grid-cols-2 gap-16 items-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsx("div", { className: "inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-white/20", children: /* @__PURE__ */ jsx("span", { className: "text-blue-300 font-medium text-sm uppercase tracking-wide", children: "🎯 Consulta Gratuita" }) }),
          /* @__PURE__ */ jsx("h2", { className: "text-2xl lg:text-3xl xl:text-4xl font-bold text-white leading-tight", children: /* @__PURE__ */ jsx("span", { className: "bg-gradient-to-r from-white via-blue-100 to-purple-200 bg-clip-text text-transparent", children: title }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-yellow-300", children: [
            /* @__PURE__ */ jsx("svg", { className: "w-6 h-6", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z", clipRule: "evenodd" }) }),
            /* @__PURE__ */ jsx("span", { className: "text-lg font-medium", children: "Resposta em até 2 horas • Consulta 100% gratuita • Sem compromisso" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-gray-200 text-lg", children: "Análise gratuita do seu negócio" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-gray-200 text-lg", children: "Proposta personalizada sem custo" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
            /* @__PURE__ */ jsx("span", { className: "text-gray-200 text-lg", children: "Demonstração do potencial de crescimento" })
          ] })
        ] })
      ] }),
      button && /* @__PURE__ */ jsx("div", { className: "bg-white/10 backdrop-blur-md rounded-3xl p-8 lg:p-10 border border-white/20 shadow-2xl", children: /* @__PURE__ */ jsxs(
        "form",
        {
          className: "space-y-6",
          onSubmit: handleSubmit(onSubmit),
          children: [
            /* @__PURE__ */ jsxs("div", { className: "text-center mb-8", children: [
              /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-white mb-2", children: "Consulta Gratuita" }),
              /* @__PURE__ */ jsx("p", { className: "text-gray-300 text-sm", children: "Preencha seus dados abaixo" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "block text-white font-medium mb-3 text-lg", children: "Nome Completo *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    ...register("name"),
                    id: "name",
                    type: "text",
                    className: `w-full rounded-xl border-0 bg-white/20 backdrop-blur-sm px-6 py-5 text-white placeholder-white/70 shadow-lg ring-2 transition-all duration-300 text-lg ${errors.name ? "ring-red-400 focus:ring-red-400" : "ring-white/20 focus:ring-4 focus:ring-yellow-400/50"}`,
                    placeholder: "Digite seu nome completo"
                  }
                ),
                errors.name && /* @__PURE__ */ jsxs("p", { className: "mt-2 text-red-400 text-sm flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
                  errors.name.message
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "email", className: "block text-white font-medium mb-3 text-lg", children: "E-mail Profissional *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    ...register("email"),
                    id: "email",
                    type: "email",
                    autoComplete: "email",
                    className: `w-full rounded-xl border-0 bg-white/20 backdrop-blur-sm px-6 py-5 text-white placeholder-white/70 shadow-lg ring-2 transition-all duration-300 text-lg ${errors.email ? "ring-red-400 focus:ring-red-400" : "ring-white/20 focus:ring-4 focus:ring-yellow-400/50"}`,
                    placeholder: "seu.email@empresa.com.br"
                  }
                ),
                errors.email && /* @__PURE__ */ jsxs("p", { className: "mt-2 text-red-400 text-sm flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
                  errors.email.message
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "phone", className: "block text-white font-medium mb-3 text-lg", children: "WhatsApp *" }),
                /* @__PURE__ */ jsx(
                  InputMask,
                  {
                    ...register("phone"),
                    mask: "(99) 99999-9999",
                    id: "phone",
                    type: "tel",
                    autoComplete: "tel",
                    className: `w-full rounded-xl border-0 bg-white/20 backdrop-blur-sm px-6 py-5 text-white placeholder-white/70 shadow-lg ring-2 transition-all duration-300 text-lg ${errors.phone ? "ring-red-400 focus:ring-red-400" : "ring-white/20 focus:ring-4 focus:ring-yellow-400/50"}`,
                    placeholder: "(11) 98926-6354"
                  }
                ),
                errors.phone && /* @__PURE__ */ jsxs("p", { className: "mt-2 text-red-400 text-sm flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
                  errors.phone.message
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "message", className: "block text-white font-medium mb-3 text-lg", children: "Conte-nos sobre seu projeto" }),
                /* @__PURE__ */ jsx(
                  "textarea",
                  {
                    ...register("message"),
                    id: "message",
                    rows: 4,
                    className: `w-full rounded-xl border-0 bg-white/20 backdrop-blur-sm px-6 py-5 text-white placeholder-white/70 shadow-lg ring-2 transition-all duration-300 resize-none text-lg ${errors.message ? "ring-red-400 focus:ring-red-400" : "ring-white/20 focus:ring-4 focus:ring-yellow-400/50"}`,
                    placeholder: "Descreva brevemente seu negócio e quais desafios você gostaria de resolver..."
                  }
                ),
                errors.message && /* @__PURE__ */ jsxs("p", { className: "mt-2 text-red-400 text-sm flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
                  errors.message.message
                ] })
              ] })
            ] }),
            message && /* @__PURE__ */ jsx("div", { className: `p-6 rounded-xl ${message.type === "success" ? "bg-green-500/20 border-2 border-green-400 text-green-100" : "bg-red-500/20 border-2 border-red-400 text-red-100"}`, children: /* @__PURE__ */ jsx("p", { className: "text-lg font-medium", children: message.text }) }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "submit",
                disabled: isLoading,
                className: `w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold py-6 px-8 rounded-xl shadow-2xl transform transition-all duration-300 text-xl ${isLoading ? "opacity-50 cursor-not-allowed" : "hover:scale-105 hover:-translate-y-1 hover:shadow-3xl"}`,
                children: isLoading ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-3", children: [
                  /* @__PURE__ */ jsxs("svg", { className: "animate-spin h-6 w-6", viewBox: "0 0 24 24", children: [
                    /* @__PURE__ */ jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4", fill: "none" }),
                    /* @__PURE__ */ jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
                  ] }),
                  /* @__PURE__ */ jsx("span", { className: "text-lg", children: "Enviando..." })
                ] }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-3", children: [
                  /* @__PURE__ */ jsx("span", { children: button.label }),
                  /* @__PURE__ */ jsx("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 7l5 5m0 0l-5 5m5-5H6" }) })
                ] })
              }
            ),
            /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx("p", { className: "text-white/60 text-sm", children: "🔒 Seus dados estão seguros • Resposta garantida em até 2 horas" }) })
          ]
        }
      ) })
    ] }) }) })
  ] });
};

const Stats = ({ data: { title, stats } }) => {
  if (!stats || stats.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsx("section", { className: "py-16 sm:py-24 bg-gradient-to-br from-blue-50 to-purple-50", "data-animate": true, children: /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsxs("div", { className: "text-center mb-16", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-h2-md font-bold tracking-tight text-gray-900 mb-4", children: title }),
      /* @__PURE__ */ jsx("div", { className: "w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4", children: stats.map((stat, index) => /* @__PURE__ */ jsx(
      "div",
      {
        className: "relative group",
        children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
            /* @__PURE__ */ jsx("div", { className: "text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2", children: stat.value }),
            /* @__PURE__ */ jsx("div", { className: "text-lg font-semibold text-gray-900 mb-1", children: stat.label }),
            /* @__PURE__ */ jsx("div", { className: "text-sm text-gray-600", children: stat.description })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "absolute top-4 right-4 w-8 h-8 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full opacity-50 group-hover:opacity-100 transition-opacity duration-300" })
        ] })
      },
      index
    )) }),
    /* @__PURE__ */ jsx("div", { className: "text-center mt-12", children: /* @__PURE__ */ jsxs("p", { className: "text-gray-600 max-w-2xl mx-auto", children: [
      "Estes números representam a média dos resultados obtidos pelos nossos clientes nos últimos 12 meses.",
      /* @__PURE__ */ jsx("span", { className: "font-semibold text-gray-900", children: " Seu negócio pode ser o próximo!" })
    ] }) })
  ] }) });
};

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Desenvolvimento de Software Sob Medida | ERP/CRM | Devnic - S\xE3o Paulo", "description": "\u{1F680} Aumente sua receita em at\xE9 300% com software sob medida! A Devnic desenvolve ERP personalizado, aplicativos mobile e automa\xE7\xE3o de processos para empresas. Mais de 50 clientes transformados. Consulta gratuita em S\xE3o Paulo. \u2B50 Resultados garantidos em 90 dias!" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <section id="home"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "contentImage", "data": {
    label: `\u{1F680} Resultados Garantidos em 90 dias`,
    logo: "logo",
    title: `Transforme Seu Neg\xF3cio com Software Que REALMENTE Funciona`,
    description: `Pare de perder dinheiro com processos manuais! Desenvolvemos solu\xE7\xF5es sob medida que aumentam sua receita em at\xE9 300% e reduzem custos operacionais em 60%. J\xE1 ajudamos mais de 50 empresas a automatizar processos e acelerar o crescimento.`,
    image: "heroImg",
    button: {
      text: "Quero uma Consulta GRATUITA",
      link: "#contato",
      variant: "primary"
    }
  } })} </section> ${renderComponent($$result2, "Stats", Stats, { "data": {
    title: "N\xFAmeros que Comprovam Nossa Excel\xEAncia",
    stats: [
      {
        value: "300%",
        label: "Aumento m\xE9dio de receita",
        description: "dos nossos clientes"
      },
      {
        value: "50+",
        label: "Empresas transformadas",
        description: "em diversos segmentos"
      },
      {
        value: "60%",
        label: "Redu\xE7\xE3o de custos",
        description: "operacionais m\xE9dia"
      },
      {
        value: "90 dias",
        label: "Prazo m\xE9dio",
        description: "para ver resultados"
      }
    ]
  } })} <section id="servicos"> ${renderComponent($$result2, "Service", Service, { "data": {
    aboveTitle: "Solu\xE7\xF5es Que Geram Resultados",
    title: "Transformamos Sua Empresa em uma M\xE1quina de Vendas",
    description: "N\xE3o vendemos apenas software - entregamos resultados mensur\xE1veis que impactam diretamente no seu faturamento. Cada solu\xE7\xE3o \xE9 desenvolvida com foco no ROI e na transforma\xE7\xE3o digital real.",
    services: [
      {
        title: "ERP/CRM Personalizado",
        description: "Sistema completo que centraliza todas as opera\xE7\xF5es, elimina retrabalho e aumenta a produtividade da equipe em at\xE9 80%. Controle total do funil de vendas e gest\xE3o financeira em tempo real.",
        icon: "cloud"
      },
      {
        title: "Aplicativo Mobile Lucrativo",
        description: "Apps que se pagam sozinhos! Desenvolvemos aplicativos que geram receita recorrente, aumentam o ticket m\xE9dio e fidelizam clientes. Integra\xE7\xE3o completa com seus sistemas existentes.",
        icon: "lock"
      },
      {
        title: "Automa\xE7\xE3o Inteligente",
        description: "Elimine tarefas repetitivas e libere sua equipe para focar no que importa: vender mais! Automatizamos desde follow-up de clientes at\xE9 emiss\xE3o de relat\xF3rios financeiros.",
        icon: "repeat"
      },
      {
        title: "Consultoria Estrat\xE9gica",
        description: "An\xE1lise completa dos seus processos com plano de a\xE7\xE3o para aumentar receita. Identificamos oportunidades de crescimento e implementamos solu\xE7\xF5es que geram ROI imediato.",
        icon: "fingerprint"
      }
    ]
  } })} </section> ${renderComponent($$result2, "Logos", Logos, { "data": {
    title: "Empresas Que J\xE1 Transformaram Seus Resultados",
    logos: ["logo1", "logo2"]
  } })} <section id="sobre"> ${renderComponent($$result2, "ImageContent", ImageContent, { "data": {
    aboveTitle: "Por Que Escolher a Devnic?",
    description: "Somos diferentes porque focamos no que realmente importa: RESULTADOS. N\xE3o entregamos apenas c\xF3digo, entregamos solu\xE7\xF5es que impactam diretamente no seu faturamento. Nossa metodologia comprovada combina tecnologia de ponta com estrat\xE9gia de neg\xF3cios para garantir o sucesso do seu projeto.",
    image: "about",
    title: "Metodologia Exclusiva que Garante 300% Mais Resultados",
    imagePosition: "right"
  } })} ${renderComponent($$result2, "ImageContent", ImageContent, { "data": {
    aboveTitle: "\u26A1 Transforma\xE7\xE3o Garantida",
    description: "Imagine sua empresa funcionando como um rel\xF3gio su\xED\xE7o: processos autom\xE1ticos, vendas fluindo naturalmente e voc\xEA tendo tempo para focar na expans\xE3o. Isso n\xE3o \xE9 sonho, \xE9 realidade para nossos clientes. Pare de competir por pre\xE7o e comece a dominar seu mercado com tecnologia que funciona.",
    image: "partner",
    title: "Seja o L\xEDder do Seu Mercado, N\xE3o Mais um Concorrente",
    imagePosition: "left"
  } })} </section> <section id="depoimentos"> ${renderComponent($$result2, "Testimonials", Testimonials, { "data": {
    aboveTitle: "Clientes Reais, Resultados Reais",
    title: "Veja Como Transformamos Neg\xF3cios em M\xE1quinas de Lucro",
    authors: [
      {
        authorName: "Carlos Silva",
        authorRole: "CEO - TechSolutions",
        content: "Em 3 meses o sistema da Devnic aumentou nossas vendas em 250%. O que lev\xE1vamos 2 horas para fazer, agora \xE9 autom\xE1tico. Nossa equipe consegue focar 100% em vendas e o resultado apareceu no faturamento imediatamente."
      },
      {
        authorName: "Maria Santos",
        authorRole: "Diretora Comercial - InnovaCorp",
        content: "Investimos R$ 50.000 no sistema e em 4 meses j\xE1 recuperamos o investimento. O controle que temos agora \xE9 impressionante - sabemos exatamente de onde vem cada real. Recomendo de olhos fechados!"
      },
      {
        authorName: "Roberto Lima",
        authorRole: "Fundador - LogisFast",
        content: "O app que desenvolveram para n\xF3s gerou R$ 200.000 em receita adicional s\xF3 no primeiro ano. Nossos clientes amam a facilidade e n\xF3s amamos os resultados. Parceria que realmente vale a pena!"
      }
    ]
  } })} </section> <section id="contato"> ${renderComponent($$result2, "Newsletter", Newsletter, { "data": {
    button: {
      label: "QUERO MINHA CONSULTA GRATUITA AGORA",
      link: "/"
    },
    title: "\u{1F3AF} ATEN\xC7\xC3O: \xDAltima Chance de Transformar Seu Neg\xF3cio Este Ano! Consulta gratuita limitada - Apenas 10 vagas por m\xEAs. Descubra como aumentar sua receita em at\xE9 300% com solu\xE7\xF5es sob medida que realmente funcionam."
  } })} </section> </main> ` })}`;
}, "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/index.astro", void 0);

const $$file = "/Users/claytonrodrigues/Documents/projects/devnic.com.br/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
